export const PATHS = {
	DEPARTMENT:'/department',
	CUSTOMER:'/customer',
	EMPLOYEE:'/employee',
	MATERIAL:'/material',
	STANDARD:'/standard',
	PARAMETER:'/parameter',
	PARAMETERBYSTANDARD:'/parameter/by-standard',
	BOOKINGS:'/bookings',
	TESTS:'/tests',
	SAMPLES:'/sample'
	
}