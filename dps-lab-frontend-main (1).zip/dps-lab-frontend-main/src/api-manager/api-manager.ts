import axios from "axios";
import { PATHS } from "./paths";

// const BASE_URL:string = 'http://localhost:3000';
const BASE_URL:string = 'http://13.51.163.209:3000';

const axiosInstance = axios.create({
	baseURL:BASE_URL,
})

const handleError = (error:any) => {
	console.error(error);
	return error?.response;
  };

axiosInstance.interceptors.request.use(config=>{
	const authToken = sessionStorage.getItem("@authToken");
	if (authToken) {
	  config.headers.Authorization = `Bearer ${authToken}`;
	}
	return config;
})

export class ApiManager{
	static createDepartment:any = async (data:any) => {
		try {
			const response = await axiosInstance.post(PATHS.DEPARTMENT,data);
			return response
		} catch (error) {
			return handleError(error)
		}
	}	
	static fetchDepartments = async () => {
		try {
			return await axiosInstance.get(PATHS.DEPARTMENT);
		} catch (error) {
			return handleError(error)
		}
	}
	static createCustomer:any = async (data:any) => {
		try {
			const response = await axiosInstance.post(PATHS.CUSTOMER,data);
			return response
		} catch (error) {
			return handleError(error)
		}
	}	
	static fetchCustomers = async () => {
		try {
			return await axiosInstance.get(PATHS.CUSTOMER);
		} catch (error) {
			return handleError(error)
		}
	}
	static createEmployee = async (data:any) => {
		try {
			return await axiosInstance.post(PATHS.EMPLOYEE,data);
		} catch (error) {
			return handleError(error)
		}
	}
	static fetchEmployee = async () => {
		try {
			return await axiosInstance.get(PATHS.EMPLOYEE);
		} catch (error) {
			return handleError(error)
		}
	}
	static createMaterial = async (data:any) => {
		try {
			return await axiosInstance.post(PATHS.MATERIAL,data);
		} catch (error) {
			return handleError(error)
		}
	}
	static fetchMaterials = async () => {
		try {
			return await axiosInstance.get(PATHS.MATERIAL);
		} catch (error) {
			return handleError(error)
		}
	}
	static createParameter = async (data:any) => {
		try {
			return await axiosInstance.post(PATHS.PARAMETER,data);
		} catch (error) {
			return handleError(error)
		}
	}
	static fetchParameters = async () => {
		try {
			return await axiosInstance.get(PATHS.PARAMETER);
		} catch (error) {
			return handleError(error)
		}
	}
	static fetchParametersByStandard = async (id:string) => {
		try {
			return await axiosInstance.get(PATHS.PARAMETERBYSTANDARD+'/'+id);
		} catch (error) {
			return handleError(error)
		}
	}

	static createStandard = async (data:any) => {
		try {
			return await axiosInstance.post(PATHS.STANDARD,data);
		} catch (error) {
			return handleError(error)
		}
	}
	static fetchStandards = async () => {
		try {
			return await axiosInstance.get(PATHS.STANDARD);
		} catch (error) {
			return handleError(error)
		}
	}
	static createBookings = async (data:any) => {
		try {
			return await axiosInstance.post(PATHS.BOOKINGS,data);
		} catch (error) {
			return handleError(error)
		}
	}
	static fetchBookings = async () => {
		try {
			return await axiosInstance.get(PATHS.BOOKINGS);
		} catch (error) {
			return handleError(error)
		}
	}
	static createSamples = async (data:any) => {
		try {
			return await axiosInstance.post(PATHS.SAMPLES,data);
		} catch (error) {
			return handleError(error)
		}
	}
	static fetchSamples = async () => {
		try {
			return await axiosInstance.get(PATHS.SAMPLES);
		} catch (error) {
			return handleError(error)
		}
	}
}

