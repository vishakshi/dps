import { createBrowserRouter } from "react-router-dom";
import MyApp from "../pages/my-app";
import Master from "../pages/master";
import Department from "../pages/department";
import Customer from "../pages/customer";
import Employee from "../pages/employee";
import Parameter from "../pages/parameter";
import Material from "../pages/material";
import Bookings from "../pages/booking";
import Sample from "../pages/samples";
import Tests from "../pages/tests";

export const router = createBrowserRouter([
	{
		path:'/',
		element:<MyApp />,
	},
	{
		path:'/bookings',
		element:<Bookings/>
	},
	{
		path:'/samples',
		element:<Sample/>
	},
	{
		path:'/masters',
		element:<Master />,
	},
	{
		path:'/department',
		element:<Department />,
	},
	{
		path:'/customer',
		element:<Customer />,
	},
	{
		path:'/employee',
		element:<Employee />,
	},
	{
		path:'/parameter',
		element:<Parameter />,
	},
	{
		path:'/tests',
		element:<Tests />,
	},
	{
		path:'/material',
		element:<Material />,
	}
])