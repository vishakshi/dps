import ResponsiveAppBar from '../component/app-bar';
import { Box, Typography, Button } from '@mui/material';
import Breadcrumb from '../component/breadcrumb';
import SampleTable from '../component/samples/table';
import Add from '@mui/icons-material/Add';
import React, { useEffect } from 'react';
import SampleForm from '../component/samples/add';
import { ApiManager } from '../api-manager/api-manager';
import { CustomAlertType } from '../static-data/type';
import CustomAlert from '../component/custom-alert';
import { SampleType } from '../static-data/type';
const Sample = () => {
  const [addOpen, setAddOpen] = React.useState<boolean>(false);
  const [data, setData] = React.useState<SampleType[]>([]);
  const [recall, setRecall] = React.useState<number>(0);
  const [alertData, setAlertData] = React.useState<CustomAlertType>({ severity: '', message: '' });

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await ApiManager.fetchSamples();
        if (Array.isArray(response.data)) {
          setData(response.data);
        } else {
          setAlertData({ severity: 'error', message: 'Failed to fetch samples' });
        }
      } catch (error) {
        setAlertData({ severity: 'error', message: 'Error fetching samples: ' });
      }
    };

    fetchData();
  }, [recall]);

  return (
    <>
      {alertData.message && (
        <CustomAlert
          onOpen={Boolean(alertData.message)}
          onClose={() => setAlertData({ severity: '', message: '' })}
          severity={alertData.severity || 'success'}
          position="center"
          message={alertData.message}
        />
      )}
      <ResponsiveAppBar />
      <Box p={3}>
        <Breadcrumb currentPage="Samples" />
        <Typography sx={{ textAlign: 'center' }} variant="h3">
          Samples
        </Typography>
      </Box>
      <Box sx={{ display: 'flex', justifyContent: 'flex-end', px: 3, pb: 3 }}>
        <Button variant="contained" onClick={() => setAddOpen(true)} startIcon={<Add />}>
          Add New
        </Button>
      </Box>
      <Box px={3}>
        <SampleTable data={data} />
        {addOpen && (
          <SampleForm
            setAlertData={setAlertData}
            recall={() => setRecall(prev => prev + 1)} // Using functional update to ensure state updates correctly
            onOpen={addOpen}
            onClose={() => setAddOpen(false)}
          />
        )}
      </Box>
    </>
  );
};

export default Sample;
