import ResponsiveAppBar from '../component/app-bar'
import { Box, Typography, Button } from '@mui/material'
import Breadcrumb from '../component/breadcrumb'
import DepartmentTable from '../component/department/table'
import Add from '@mui/icons-material/Add'
import React, { useEffect } from 'react'
import AddDepartment from '../component/department/add'
import { ApiManager } from '../api-manager/api-manager'
import { CustomAlertType, DepartmentType } from '../static-data/type'
import CustomAlert from '../component/custom-alert'


const Department = () => {
	const [addOpen,setAddOpen] = React.useState<boolean>(false);
	const [data,setData] = React.useState<DepartmentType[]>([]);
	const [recall,setRecall] = React.useState<number>(0);
	const [alertData,setAlertData] = React.useState<CustomAlertType>({severity:'',message:''});
	useEffect(()=>{
		;(async()=>{
			const response = await ApiManager.fetchDepartments();
			console.log(response);
			if(Array.isArray(response.data)){
				setData(response.data);
			}
		}
		)();
	},[recall])
  return (
	<>
	{alertData.message && <CustomAlert onOpen={Boolean(alertData.message)} onClose={()=>setAlertData({severity:'',message:''})} severity='success' position='center' message={alertData.message} />}
	<ResponsiveAppBar/>
	<Box p={3}>
		<Breadcrumb routes={[{path:'/masters',name:'Masters'}]} currentPage='Departments' />
		<Typography sx={{textAlign:'center'}} variant='h3'>Departments</Typography>
	</Box>
	<Box sx={{display:'flex',justifyContent:'flex-end',px:3,pb:3}}>
		<Button variant="contained" onClick={()=>setAddOpen(true)} startIcon={<Add/>}>Add New</Button>
	</Box>
	<Box px={3}>
		<DepartmentTable data={data} />
		{addOpen && <AddDepartment setAlertData={setAlertData} recall={()=>setRecall(recall + 1)} onOpen={addOpen} onClose={()=>setAddOpen(false)}/>}
	</Box>
	</>
  )
}

export default Department