import ResponsiveAppBar from '../component/app-bar'
import { Box, Typography, Button } from '@mui/material'
import Breadcrumb from '../component/breadcrumb'
import EmployeeTable from '../component/employee/table'
import Add from '@mui/icons-material/Add'
import React, { useEffect } from 'react'
import AddEmployee from '../component/employee/add'
import { ApiManager } from '../api-manager/api-manager'
import {  CustomAlertType, EmployeeType } from '../static-data/type'
import CustomAlert from '../component/custom-alert'


const Employee = () => {
	const [addOpen,setAddOpen] = React.useState<boolean>(false);
	const [data,setData] = React.useState<EmployeeType[]>([]);
	const [recall,setRecall] = React.useState<number>(0);
	const [alertData,setAlertData] = React.useState<CustomAlertType>({severity:'',message:''});

	useEffect(()=>{
		;(async()=>{
			const response = await ApiManager.fetchEmployee();
			console.log(response);
			if(Array.isArray(response.data)){
				setData(response.data);
			}
		}
		)();
	},[recall])
  return (
	<>
	{alertData.message && <CustomAlert onOpen={Boolean(alertData.message)} onClose={()=>setAlertData({severity:'',message:''})} severity='success' position='center' message={alertData.message} />}
	<ResponsiveAppBar/>
	<Box p={3}>
		<Breadcrumb routes={[{path:'/masters',name:'Masters'}]} currentPage='Employee' />
		<Typography sx={{textAlign:'center'}} variant='h3'>Employee</Typography>
	</Box>
 <Box sx={{display:'flex',justifyContent:'flex-end',px:3,pb:3}}>
		<Button variant="contained" onClick={()=>setAddOpen(true)} startIcon={<Add/>}>Add New</Button>
	</Box> 
	<Box px={3}>
		<EmployeeTable  data={data} />
		{addOpen && <AddEmployee setAlertData={setAlertData} recall={()=>setRecall(recall + 1)} onOpen={addOpen} onClose={()=>setAddOpen(false)}/>}
	</Box>
	</>
  )
}

export default Employee