import ResponsiveAppBar from '../component/app-bar';
import { Box, Typography, Button, Dialog, DialogTitle, DialogContent, DialogActions } from '@mui/material';
import Breadcrumb from '../component/breadcrumb';
import BookingTable from '../component/bookings/table';
import Add from '@mui/icons-material/Add';
import React, { useEffect } from 'react';
import AddBooking from '../component/bookings/add';
import { ApiManager } from '../api-manager/api-manager';
import { BookingType, CustomAlertType } from '../static-data/type';
import CustomAlert from '../component/custom-alert';

const Bookings = () => {
  const [addOpen, setAddOpen] = React.useState<boolean>(false);
  const [data, setData] = React.useState<BookingType[]>([]);
  const [recall, setRecall] = React.useState<number>(0);
  const [alertData, setAlertData] = React.useState<CustomAlertType>({ severity: '', message: '' });

  useEffect(() => {
    const fetchBookings = async () => {
      const response = await ApiManager.fetchBookings();
      if (Array.isArray(response.data)) {
        setData(response.data);
      }
    };
    fetchBookings();
  }, [recall]);

  return (
    <>
      {alertData.message && (
        <CustomAlert
          onOpen={Boolean(alertData.message)}
          onClose={() => setAlertData({ severity: '', message: '' })}
          severity={alertData.severity}
          position='center'
          message={alertData.message}
        />
      )}
      <ResponsiveAppBar />
      <Box p={3}>
        <Breadcrumb currentPage='Bookings' />
        <Typography sx={{ textAlign: 'center' }} variant='h3'>Bookings</Typography>
      </Box>
      <Box sx={{ display: 'flex', justifyContent: 'flex-end', px: 3, pb: 3 }}>
        <Button variant="contained" onClick={() => setAddOpen(true)} startIcon={<Add />}>Add New</Button>
      </Box>
      <Box px={3}>
        <BookingTable data={data} />
        <Dialog
          open={addOpen}
          onClose={() => setAddOpen(false)}
          fullWidth
          maxWidth="md"
          PaperProps={{
            style: {
              margin: 0,
              overflow: 'hidden',
            },
          }}
        >
          <DialogTitle>Add New Booking</DialogTitle>
          <DialogContent>
            <AddBooking 
              setAlertData={setAlertData}
              recall={() => setRecall(recall + 1)}
              onClose={() => setAddOpen(false)} 
              onOpen={addOpen}
            />
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setAddOpen(false)} color="primary">Cancel</Button>
          </DialogActions>
        </Dialog>
      </Box>
    </>
  );
};

export default Bookings;

//   return (
//     <>
//       {alertData.message && (
//         <CustomAlert
//           onOpen={Boolean(alertData.message)}
//           onClose={() => setAlertData({ severity: '', message: '' })}
//           severity={alertData.severity}
//           position='center'
//           message={alertData.message}
//         />
//       )}
//       <ResponsiveAppBar />
//       <Box p={3}>
//         <Breadcrumb routes={[{ path: '/masters', name: 'Masters' }]} currentPage='Bookings'/>
//         <Typography sx={{ textAlign: 'center' }} variant='h3'>Bookings</Typography>
//       </Box>
//       <Box sx={{ display: 'flex', justifyContent: 'flex-end', px: 3, pb: 3 }}>
//         <Button variant="contained" onClick={() => setAddOpen(true)} startIcon={<Add />}>Add New</Button>
//       </Box>
//       <Box px={3}>
//         <BookingTable data={data} />
//         <Dialog
//       open={addOpen}
//       onClose={() => setAddOpen(false)}
//       fullWidth
//       maxWidth="xl"
//       PaperProps={{
//         style: {
//           height: '100vh',
//           width: '100%',
//           margin: 0,
//           overflow: 'hidden',
//         },
//       }}
//     >
//           <DialogTitle>Add New Booking</DialogTitle>
//           <DialogContent>
//             <AddBooking 
//               setAlertData={setAlertData}
//               recall={() => setRecall(recall + 1)}
//               onClose={() => setAddOpen(false)} // Close the AddBooking component
//             />
//           </DialogContent>
//           <DialogActions>
//             <Button onClick={() => setAddOpen(false)} color="primary">Cancel</Button>
//           </DialogActions>
//         </Dialog>
//       </Box>
//     </>
//   );
// };

// export default Bookings;
