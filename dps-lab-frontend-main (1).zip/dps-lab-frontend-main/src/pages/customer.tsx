import React, { useEffect } from 'react'
import ResponsiveAppBar from '../component/app-bar'
import { Box, Button, Typography } from '@mui/material'
import Breadcrumb from '../component/breadcrumb'
import CustomerTable from '../component/customer/table'
import CustomerAdd from '../component/customer/add'
import { Add } from '@mui/icons-material'
import { ApiManager } from '../api-manager/api-manager'
import { CustomAlertType, CustomerType } from '../static-data/type'
import CustomAlert from '../component/custom-alert'

const Customer= () => {
	const [addOpen,setAddOpen] = React.useState(false);
	const [data,setData] = React.useState<CustomerType[]>([]);
	const [recall,setRecall] = React.useState<number>(0);
	const [alertData,setAlertData] = React.useState<CustomAlertType>({severity:'',message:''});
	useEffect(()=>{
		;(async()=>{
			const response = await ApiManager.fetchCustomers();
			console.log(response);
			if(Array.isArray(response.data)){
				setData(response.data);
			}
		}
		)();
	},[recall])
  return (
	<>
	{alertData.message && <CustomAlert onOpen={Boolean(alertData.message)} onClose={()=>setAlertData({severity:'',message:''})} severity='success' position='center' message={alertData.message} />}
	<ResponsiveAppBar/>
	<Box p={3}>
		<Breadcrumb routes={[{path:'/masters',name:'Masters'}]} currentPage='Customer'/>
		<Typography sx={{textAlign:'center'}} variant='h3'>Customers</Typography>
	</Box>
	<Box sx={{display:'flex',justifyContent:'flex-end',px:3,pb:3}}>
		<Button variant="contained" onClick={()=>setAddOpen(true)} startIcon={<Add/>}>Add New</Button>
	</Box>
	<Box px={3}>
		<CustomerTable data={data} />
		{addOpen && <CustomerAdd setAlertData={setAlertData} recall={()=>setRecall(recall + 1)}  onOpen={addOpen} onClose={()=>setAddOpen(false)}/>}
	</Box>
	</>
  )
}

export default Customer