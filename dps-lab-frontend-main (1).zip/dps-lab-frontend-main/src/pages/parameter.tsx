import ResponsiveAppBar from '../component/app-bar'
import { Box, Typography, Button } from '@mui/material'
import Breadcrumb from '../component/breadcrumb'
import Add from '@mui/icons-material/Add'
import React, { useEffect } from 'react'
import { ApiManager } from '../api-manager/api-manager'
import {  CustomAlertType, StandardType } from '../static-data/type'
import CustomAlert from '../component/custom-alert'
import CollapsibleTable from '../component/parameters/standard-table'
import AddStandard from '../component/parameters/add'


const Parameter = () => {
	const [addOpen,setAddOpen] = React.useState<boolean>(false);
	const [data,setData] = React.useState<StandardType[]>([]);
	const [recall,setRecall] = React.useState<number>(0);
	const [alertData,setAlertData] = React.useState<CustomAlertType>({severity:'',message:''});

	useEffect(()=>{
		;(async()=>{
			const response = await ApiManager.fetchStandards();
			console.log(response);
			if(Array.isArray(response.data)){
				setData(response.data);
			}
		}
		)();
	},[recall])
  return (
	<>
	{alertData.message && <CustomAlert onOpen={Boolean(alertData.message)} onClose={()=>setAlertData({severity:'',message:''})} severity='success' position='center' message={alertData.message} />}
	<ResponsiveAppBar/>
	<Box p={3}>
		<Breadcrumb routes={[{path:'/masters',name:'Masters'}]} currentPage='Parameter' />
		<Typography sx={{textAlign:'center'}} variant='h3'>Parameter</Typography>
	</Box>
 
 
 <Box sx={{display:'flex',justifyContent:'flex-end',px:3,pb:3}}>
 <Box sx={{display:'flex', textAlign: 'left'}}>
  </Box>
		<Button variant="contained" onClick={()=>setAddOpen(true)} startIcon={<Add/>}>Add Standard</Button>
	</Box>
	<Box px={3}>
		<CollapsibleTable setAlertData={setAlertData} data={data} />
		{addOpen && <AddStandard setAlertData={setAlertData} recall={()=>setRecall(recall + 1)} onOpen={addOpen} onClose={()=>setAddOpen(false)}/>}
	</Box>
	</>
  )
}

export default Parameter

