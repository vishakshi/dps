import ResponsiveAppBar from '../component/app-bar'
import { Box,Grid2 as Grid,Typography } from '@mui/material'
import MainCard from '../component/main-card'
import { dashboardData } from '../static-data/data'

const MyApp = () => {
  return (
	<>
	<ResponsiveAppBar/>
	<Box bgcolor='#FCFCFC' height={'88vh'} sx={{overflowX:'hidden'}}>
	<Typography variant='h3' p={3}>My Apps</Typography>
	<Box maxWidth='xl' px={2} mx={'auto'}>
		<Grid container justifyContent='center' spacing={2} alignItems='centers'>
		{dashboardData.map((item)=>(
			<Grid key={item.id} size={{xs:6,md:2}}>
			<MainCard {...item} />
			</Grid>
		))}
		</Grid>
	</Box>
	</Box>
	</>
  )
}

export default MyApp