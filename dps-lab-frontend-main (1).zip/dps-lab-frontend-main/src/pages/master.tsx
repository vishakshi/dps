import ResponsiveAppBar from '../component/app-bar'
import { Box,Grid2 as Grid,Typography } from '@mui/material'
import Breadcrumb from '../component/breadcrumb'
import MainCard from '../component/main-card'
import { masterData } from '../static-data/data'

const Master = () => {
  return (
	<>
	<ResponsiveAppBar/>
	<Box bgcolor='#FCFCFC' height={'88vh'}>
	<Box p={3}>
		<Breadcrumb  currentPage='Masters' />
		<Typography sx={{textAlign:'center'}} variant='h3'>Masters</Typography>
	</Box>
	<Box maxWidth='xl' mx={'auto'} px={2}>
		<Grid container justifyContent='center' spacing={2} alignItems='centers'>
		{masterData.map((item)=>(
			<Grid key={item.id} size={{xs:6,md:2}}>
			<MainCard {...item} />
			</Grid>
		))}
		</Grid>
	</Box>
	</Box>
	</>
  )
}

export default Master