import DashboardIcon from '@mui/icons-material/Dashboard';
import QuestionAnswerIcon from '@mui/icons-material/QuestionAnswer';
import AssignmentIcon from '@mui/icons-material/Assignment';
import BookOnlineIcon from '@mui/icons-material/BookOnline';
import InventoryIcon from '@mui/icons-material/Inventory';
import ScienceIcon from '@mui/icons-material/Science';
import DescriptionIcon from '@mui/icons-material/Description';
import ReceiptIcon from '@mui/icons-material/Receipt';
import InsightsIcon from '@mui/icons-material/Insights';
import ManageAccountsIcon from '@mui/icons-material/ManageAccounts';

import BusinessIcon from '@mui/icons-material/Business'; 
import ContactsIcon from '@mui/icons-material/Contacts'; 
import PeopleIcon from '@mui/icons-material/People'; 
import AttachMoneyIcon from '@mui/icons-material/AttachMoney';
import GroupIcon from '@mui/icons-material/Group'; 
import SettingsIcon from '@mui/icons-material/Settings';
import React from 'react';

interface dashboardDataType {
    id:string;
    heading:string;
    icon:React.ReactElement;
    description:string;
    path:string;
}
export const dashboardData:dashboardDataType[] = [
    {
		id:'01',
        description: 'Display my business overview data.',
        icon: <DashboardIcon sx={{color:'#635BFF',fontSize:35}}/>,
        heading: 'Dashboard',
        path:'/dashboard'
    },
    {
		id:'02',
        heading: 'Enquiries',
        icon: <QuestionAnswerIcon sx={{color:'#635BFF',fontSize:35}} />,
        description: 'View all the enquiries requested and response as required.',
        path:'/enquiries'
    },
    {
		id:'03',
        heading: 'Requisitions',
        icon: <AssignmentIcon sx={{color:'#635BFF',fontSize:35}} />,
        description: 'Display requisitions and response with the quote and fulfill the requisition.',
        path:'/requisitions'
    },
    {
		id:'04',
        heading: 'Bookings',
        icon: <BookOnlineIcon sx={{color:'#635BFF',fontSize:35}} />,
        description: 'Book and manage test from request slip.',
        path:'/bookings'
    },
    {
		id:'05',
        heading: 'Samples',
        icon: <InventoryIcon sx={{color:'#635BFF',fontSize:35}} />,
        description: 'Access to sample data, condition and current state.',
        path:'/samples'
    },
    {
		id:'06',
        heading: 'Tests',
        icon: <ScienceIcon sx={{color:'#635BFF',fontSize:35}} />,
        description: 'Manage all the tests, analyst allotment, test data capture, calculation notes etc.',
        path:'/tests'
    },
    {
		id:'07',
        heading: 'Reports',
        icon: <DescriptionIcon sx={{color:'#635BFF',fontSize:35}} />,
        description: 'Upload or generate report and get it approved by supervisor/ HOD for issuing.',
        path:'/reports'
    },
    {
		id:'08',
        heading: 'Invoicing',
        icon: <ReceiptIcon sx={{color:'#635BFF',fontSize:35}} />,
        description: 'Create final invoice for sending to customer. Invoices and payments can be tracked.',
        path:'/invoices'
    },
    {
		id:'09',
        heading: 'Analytics',
        icon: <InsightsIcon sx={{color:'#635BFF',fontSize:35}} />,
        description: 'View every status of your business and can take decision for future planning.',
        path:'/analytics'
    },
    {
		id:'10',
        heading: 'Masters',
        icon: <ManageAccountsIcon sx={{color:'#635BFF',fontSize:35}} />,
        description: 'Manage to your business master data.',
        path:'/masters'
    }
];

export const masterData:dashboardDataType[] = [
    {
        id: '01',
        heading: 'Templates',
        description: 'Manage different data collection, capture and reporting form templates.',
        icon: <ReceiptIcon sx={{ color: '#635BFF', fontSize: 35 }} />,
        path: '/dashboard'
      },
      {
        id: '04',
        heading: 'Materials',
        description: 'Manage materials and product samples we deal with.',
        icon: <InventoryIcon sx={{ color: '#635BFF', fontSize: 35 }} />, // Icon for materials
        path: '/material'
      },
      {
        id: '05',
        heading: 'Departments',
        description: 'Manage departments, analysts, and their tasks.',
        icon: <BusinessIcon sx={{ color: '#635BFF', fontSize: 35 }} />, // Icon for departments
        path: '/department'
      },
      {
        id: '06',
        heading: 'Customers',
        description: 'Manage customer/client contact and address details.',
        icon: <ContactsIcon sx={{ color: '#635BFF', fontSize: 35 }} />, // Icon for customers
        path: '/customer'
      },
      {
        id: '07',
        heading: 'Employees',
        description: 'Maintain employee contact, department details, etc.',
        icon: <PeopleIcon sx={{ color: '#635BFF', fontSize: 35 }} />, // Icon for employees
        path: '/employee'
      },
      {
        id: '08',
        heading: 'Parameters',
        description: 'Manage pricing for different test parameters of all test standards we deal with.',
        icon: <AttachMoneyIcon sx={{ color: '#635BFF', fontSize: 35 }} />, // Icon for parameters
        path: '/parameter'
      },
      {
        id: '09',
        heading: 'Users',
        description: 'Manage App users of different types along with access restriction.',
        icon: <GroupIcon sx={{ color: '#635BFF', fontSize: 35 }} />, // Icon for users
        path: '/users'
      },
      {
        id: '10',
        heading: 'App Configs',
        description: 'Application configs like payment types, report delivery methods, etc., manage here.',
        icon: <SettingsIcon sx={{ color: '#635BFF', fontSize: 35 }} />, // Icon for app configurations
        path: '/app-configs'
      }
]