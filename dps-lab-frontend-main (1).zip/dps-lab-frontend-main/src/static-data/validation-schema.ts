import {z} from "zod";

export const customerSchema = z.object({
    name: z.string().min(4,'Minimum 4 characters are required'),
    address: z.string().min(4,'Minimum 4 characters are required'),
    gstIn: z.string().min(15,'Minimum 15 characters are required').max(15,'Maximum 15 characters are required'),
    contactName: z.string().min(4,'Minimum 4 characters are required'),
    phone: z.string().min(10,'Minimum 10 characters are required').max(10,'Maximum 10 characters are required'),
    email: z.string().email('Email is incorrect'),
}); 

export const departmentSchema = z.object({
    name: z.string().min(4,'Minimum 4 characters are required'),
}); 

export const employeeSchema = z.object({
    name: z.string().min(4,'Minimum 4 characters are required'),
    address: z.string().min(4,'Minimum 4 characters are required'),
    phone: z.string().min(10,'Minimum 10 characters are required').max(10,'Maximum 10 characters are required'),
    email: z.string().email('Email is incorrect'),
}); 
export const materialSchema = z.object({
    name: z.string().min(4,'Minimum 4 characters are required'),
}); 
export const bookingSchema = z.object({
    customerName: z.string().min(4,'Minimum 4 characters are required'),
    billTo: z.string().min(2,'Minimum 2 characters are required').max(10,'Maximum 10 characters are required'),
    shipTo: z.string().min(2,'Minimum 2 characters are required').max(10,'Maximum 10 characters are required'),
    reqDate: z.string().min(1, "Request date is required"),
    reqRefNo: z.string().min(1, "Reference number is required"),
    bookingDate: z.string().min(1, "Booking date is required"),
    dueDate: z.string().min(1, "Due date is required"),
    comments: z.string().optional(),
    payMode: z.string().min(1, "Payment mode is required"),
    reportMode: z.string().min(1, "Report mode is required"),
    attachment: z.instanceof(File).optional()
}); 
export const parameterSchema = z.object({
    name: z.string().min(4,'Minimum 4 characters are required'),
    address: z.string().min(4,'Minimum 4 characters are required'),
    description: z.string()
    .min(1, "Description is required")
    .max(500, "Description must be less than 500 characters"),
    email: z.string().email('Email is incorrect'),
}); 

export const sampleSchema = z.object({
    sampleType: z.string().min(1, 'Sample Type is required'),
    description: z.string().min(1, 'Description is required'),
    condition: z.string().min(1, 'Condition is required'),
    packing: z.string().min(1, 'Packing is required'),
    size: z.string().min(1, 'Size/Quantity is required'),
    projectName: z.string().min(1, 'Project Name is required'),
    collectedBy: z.string().min(1, 'Collected By is required'),
    receivedBy: z.string().min(1, 'Received By is required'),
    receivedOn: z.string().min(1, 'Received On is required'), // Adjust if you are using a date type
    testStartedOn: z.string().min(1, 'Test Started On is required'), // Adjust if you are using a date type
    testEndOn: z.string().min(1, 'Test End On is required'), // Adjust if you are using a date type
    image: z.instanceof(FileList).optional() // Optional image field
});
