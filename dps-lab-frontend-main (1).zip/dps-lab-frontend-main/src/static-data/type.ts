interface CommonData {
	_id:string;
	__v:number;
}
enum BookingStatus {
    Pending = 'Pending',
    Confirmed = 'Confirmed',
    Canceled = 'Canceled',
    Completed = 'Completed'
}
export interface DepartmentType extends CommonData {
	name:string;
}

export interface CustomAlertType {
	severity:"success" | "warning" | "error" | "",
	message:string
}

export interface CustomerType extends CommonData{
	name:string;
	phone:string;
	address:string;
	contactName:string;
}

export interface EmployeeType extends CommonData{
	uid:number;
	name:string;
	address:string;
	email:string;
	phone:string;
}

export interface MaterialType extends CommonData {
	name:string;
}

export interface StandardType extends CommonData {
	uid:number;
	name:string;
    description:string;
}

export interface ParameterType extends CommonData {
	uid:number;
	name:string;
    isNabl:boolean;
    department:DepartmentType;
    currency:string;
	price:number;
}
export interface BookingType extends CommonData {
    bookingId: string;
    customerName: string;
    bookingDate: number;
    dueDate: number;
    status: BookingStatus;
    comments:string;
}

export interface SampleType extends CommonData {
	sampleType:string;
	description:string;
	condition:string;
	packing:string;
	sizeQuantity:string;
	projectName:string;
	collectedBy:string;
	receivedBy:string;
	receivedOn:Date;
	testStartedOn:Date;
	testEndOn:Date;
	sampleImage:string;
} 