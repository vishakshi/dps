import { Button, Dialog, DialogContent, Box, DialogTitle, TextField, Grid2 as Grid, Typography} from "@mui/material";
import { useForm } from "react-hook-form";
import { ApiManager } from "../../api-manager/api-manager";
import { CustomAlertType } from "../../static-data/type";
import { employeeSchema } from "../../static-data/validation-schema";
import { zodResolver } from "@hookform/resolvers/zod";
type DialogProps = {
  onOpen: boolean;
  onClose: VoidFunction;
  recall:VoidFunction;
	setAlertData:({severity,message}:CustomAlertType)=>void
};

type FormData = {
  name: string;
  address: string;
  phone: string;
  email: string;
};

const AddEmployee = ({ onOpen, onClose, recall, setAlertData }: DialogProps) => {
  const { register, handleSubmit, formState: { errors } } = useForm<FormData>({
    defaultValues: {
      name: '',
      address: '',
      phone: '',
      email: '',
    },
    resolver:zodResolver(employeeSchema)
  });

  const handleSubmitValues = async (data: FormData) => {
    const response = await ApiManager.createEmployee(data);
    console.log(response)
		if(response?.status >= 200 && response?.status <= 250){
			console.log(response)
			onClose();
			recall();
			setAlertData({severity:'success',message:'Data added successfully'})
		}else{
			const errorArr = response?.data?.message;
			if(Array.isArray(errorArr)){
				errorArr.map((data)=>{
					setAlertData({severity:'error',message:data});
				})
			}
		}
  };

  return (
    <Dialog
      fullWidth
      maxWidth="md"
      open={onOpen}
      onClose={onClose}
    >
     
     <DialogTitle>Add Employee</DialogTitle>
      <DialogContent>
        <Box component="form" onSubmit={handleSubmit(handleSubmitValues)} pt={1}>
          <Grid container columnSpacing={2}>
            {/* Row 1 */}
            <Grid size={{xs:12}}>
              <Typography variant="h6" fontWeight={700}>Employee Details</Typography>
            </Grid>
            <Grid size={{xs:12,md:6}}>
              <TextField
                {...register('name', { required: 'Name is required' })}
                label="Name"
                fullWidth
                variant="outlined"
                error={!!errors.name}
                helperText={errors.name ? errors.name.message : ''}
                margin="normal"
              />
            </Grid>
            <Grid size={{xs:12,md:6}}>
              <TextField
                {...register('address', { required: 'Address is required' })}
                label="Address"
                fullWidth
                variant="outlined"
                error={!!errors.address}
                helperText={errors.address ? errors.address.message : ''}
                margin="normal"
              />
            </Grid>

            {/* Row 2 */}
            <Grid size={{xs:12}}>
              <Typography variant="h6" fontWeight={700}>Employee Contact</Typography>
            </Grid>
            <Grid size={{xs:12,md:6}}>
              <TextField
                {...register('phone', { required: 'Phone is required' })}
                label="Phone"
                fullWidth
                variant="outlined"
                error={!!errors.phone}
                helperText={errors.phone ? errors.phone.message : ''}
                margin="normal"
              />
            </Grid>
            <Grid size={{xs:12,md:6}}>
              <TextField
                {...register('email', { required: 'Email is required' })}
                label="Email"
                fullWidth
                variant="outlined"
                error={!!errors.email}
                helperText={errors.email ? errors.email.message : ''}
                margin="normal"
              />
            </Grid>
          </Grid>
          <Box sx={{ display: 'flex', justifyContent: 'flex-end', gap: 1, mt: 2 }}>
            <Button variant="contained" onClick={onClose}>Close</Button>
            <Button variant="contained" type="submit">Add</Button>
          </Box>
        </Box>
      </DialogContent>
    </Dialog>
  );
};

export default AddEmployee;
