import Box from '@mui/material/Box';
import { DataGrid, GridColDef ,GridActionsCellItem} from '@mui/x-data-grid';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/DeleteOutlined';
import { EmployeeType } from '../../static-data/type';

export default function EmployeeTable({data}:{data:EmployeeType[]}) {

  
    const columns: GridColDef[] = [
        { 
          field: 'uid',
           headerName: 'Employee Code',// Employee code
           width:150
        },
        {
          field: 'name',
          headerName: 'Employee Name',//Employee name
          width:400,
        },
        {
          field: 'address',
          headerName: 'Employee Address',// Address
          width:150,
        },
        {
          field: 'phone',
          headerName: 'Phone Number',//Phone Number
          width:150,
        },
        {
          field: 'email',
          headerName: 'Email',//Email
          width:250,
        },
        {
            field: 'actions',
            headerName: 'Actions',
            width: 150,
            type: 'actions',
            getActions: () => [
              <GridActionsCellItem
                icon={<EditIcon />}
                label="Edit"
                color="inherit"
              />,
              <GridActionsCellItem
              icon={<DeleteIcon />}
              label="Delete"
              color="inherit"

              />,
            ],
          },
        ];

  return (
    <Box sx={{ height: 400, width: '100%' }}>
      <DataGrid
      getRowId={(row)=>row._id}
        rows={data}
        columns={columns}
        initialState={{
          pagination: {
            paginationModel: {
              pageSize: 5,
            },
          },
        }}
        pageSizeOptions={[5,10,15]}
        // checkboxSelection
        disableRowSelectionOnClick
      />
    </Box>
  );
};
