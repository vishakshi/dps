import * as React from 'react';
import { emphasize, styled } from '@mui/material/styles';
import Breadcrumbs from '@mui/material/Breadcrumbs';
import Chip from '@mui/material/Chip';
import HomeIcon from '@mui/icons-material/Home';
import { Link } from 'react-router-dom';

const StyledBreadcrumb = styled(Chip)(({ theme }) => {
  const backgroundColor =
    theme.palette.mode === 'light'
      ? theme.palette.grey[100]
      : theme.palette.grey[800];
  return {
    backgroundColor,
    height: theme.spacing(3),
    color: 'black',
	cursor:'pointer',
    fontWeight: theme.typography.fontWeightRegular,
    '&:hover, &:focus': {
      backgroundColor: emphasize(backgroundColor, 0.06),
    },
    '&:active': {
      boxShadow: theme.shadows[1],
      backgroundColor: emphasize(backgroundColor, 0.12),
    },
  };
}) as typeof Chip; 

function handleClick(event: React.MouseEvent<Element, MouseEvent>) {
  event.preventDefault();
  console.clear();
}

interface BreadcrumbPropsObj {
	path:string;
	name:string;
}

interface BreadCrumbProps {
  routes?:BreadcrumbPropsObj[];
  currentPage:string,
}

export default function Breadcrumb({routes,currentPage}:BreadCrumbProps){
  return (
    <div role="presentation" onClick={handleClick}>
      <Breadcrumbs aria-label="breadcrumb">
      <Link to='/'>
      <StyledBreadcrumb
        label="My Apps"
        icon={<HomeIcon fontSize="small" />}
      />
      </Link>
      {Array.isArray(routes) && routes.map(({path,name})=>(
        <Link key={path} to={path}>
        <StyledBreadcrumb
        label={name}
      />
      </Link>
      ))}
        
        <StyledBreadcrumb component="a" href="#" label={currentPage} />
      </Breadcrumbs>
    </div>
  );
}