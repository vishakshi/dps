import { Button, Dialog, DialogContent, Box, DialogTitle, TextField, Grid2 as Grid, Typography} from "@mui/material";
import { useForm } from "react-hook-form";
import { ApiManager } from "../../api-manager/api-manager";
import { CustomAlertType } from "../../static-data/type";
import { parameterSchema } from "../../static-data/validation-schema";
import { zodResolver } from "@hookform/resolvers/zod";
type DialogProps = {
  onOpen: boolean;
  onClose: VoidFunction;
  recall:VoidFunction;
	setAlertData:({severity,message}:CustomAlertType)=>void
};

type FormData = {
  name: string;
  address: string;
  Description: string;
  email: string;
};

const Addparameter = ({ onOpen, onClose, recall, setAlertData }: DialogProps) => {
  const { register, handleSubmit, formState: { errors } } = useForm<FormData>({
    defaultValues: {
      name: '',
      address: '',
      Description: '',
      email: '',
    },
    resolver:zodResolver(parameterSchema)
  });

  const handleSubmitValues = async (data: FormData) => {
    const response = await ApiManager.createStandard(data);
    console.log(response)
		if(response?.status >= 200 && response?.status <= 250){
			console.log(response)
			onClose();
			recall();
			setAlertData({severity:'success',message:'Data added successfully'})
		}else{
			const errorArr = response?.data?.message;
			if(Array.isArray(errorArr)){
				errorArr.map((data)=>{
					setAlertData({severity:'error',message:data});
				})
			}
		}
  };

  return (
    <Dialog
      fullWidth
      maxWidth="md"
      open={onOpen}
      onClose={onClose}
    >
     
     <DialogTitle variant='h6'>Add Standard</DialogTitle>
      <DialogContent>
        <Box component="form" onSubmit={handleSubmit(handleSubmitValues)} pt={1}>
          <Grid container columnSpacing={2}>
            <Grid size={{xs:12,md:12}}>
            <Typography variant="h6" fontWeight={700}>Test Methods/Standards</Typography>
            </Grid>
            <Grid size={{xs:12,md:6}}>
              <TextField
                {...register('name', { required: 'Name is required' })}
                label="Name"
                fullWidth
                variant="outlined"
                error={!!errors.name}
                helperText={errors.name ? errors.name.message : ''}
                margin="normal"
              />
            </Grid>
            <Grid size={{xs:12,md:6}}>
              <TextField
                {...register('Description', { required: 'Description is required' })}
                label="Description"
                fullWidth
                variant="outlined"
                error={!!errors.Description}
                helperText={errors.Description ? errors.Description.message : ''}
                margin="normal"
              />
            </Grid>
          </Grid>
          <Box sx={{ display: 'flex', justifyContent: 'flex-end', gap: 1, mt: 2 }}>
            <Button variant="contained" onClick={onClose}>Close</Button>
            <Button variant="contained" type="submit">Add</Button>
          </Box>
        </Box>
      </DialogContent>
    </Dialog>
  );
};

export default Addparameter;
