import * as React from "react";
import Box from "@mui/material/Box";
import Collapse from "@mui/material/Collapse";
import IconButton from "@mui/material/IconButton";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import KeyboardArrowUpIcon from "@mui/icons-material/KeyboardArrowUp";
import { DeleteOutline } from "@mui/icons-material";
import {
  CustomAlertType,
  DepartmentType,
  ParameterType,
  StandardType,
} from "../../static-data/type";
import { ApiManager } from "../../api-manager/api-manager";
import BorderColorOutlined from "@mui/icons-material/BorderColorOutlined";
import CheckCircleOutline from "@mui/icons-material/CheckCircleOutline";
import CancelOutlined from "@mui/icons-material/CancelOutlined";
import AddCircleOutline from "@mui/icons-material/AddCircleOutline";
import AddParameter from "./add-parameter";

function Row({
  row,
  setAlertData,
  departmentData,
}: {
  row: StandardType;
  setAlertData: ({ severity, message }: CustomAlertType) => void;
  departmentData: DepartmentType[];
}) {
  const [open, setOpen] = React.useState(false);
  const [parameterData, setParameterData] = React.useState<ParameterType[]>([]);
  const [addOpen, setAddOpen] = React.useState(false);

  const handleCollapse = async () => {
    if (open) {
      setOpen(false);
      return;
    }
    (async () => {
      const response = await ApiManager.fetchParametersByStandard(row?._id);
      if (Array.isArray(response.data)) {
        setParameterData(response.data);
      }
    })();
    setOpen(true);
  };

  return (
    <React.Fragment>
      {addOpen && (
        <AddParameter
          standard={row}
          departmentData={departmentData}
          onOpen={addOpen}
          onClose={() => setAddOpen(false)}
          setAlertData={setAlertData}
        />
      )}
      <TableRow sx={{ "& > *": { borderBottom: "unset" } }}>
        <TableCell width={30}>
          <IconButton
            aria-label="expand row"
            size="small"
            onClick={handleCollapse}
          >
            {open ? <KeyboardArrowUpIcon /> : <KeyboardArrowDownIcon />}
          </IconButton>
        </TableCell>
        <TableCell align="left" component="th" scope="row">
          {row.name}
        </TableCell>
        <TableCell align="left">{row?.uid}</TableCell>
        <TableCell align="center"></TableCell>
        <TableCell align="left"></TableCell>
        <TableCell align="right"></TableCell>
        <TableCell align="right">
          <IconButton onClick={() => setAddOpen(true)}>
            <AddCircleOutline sx={{ color: "#635BFF" }} />
          </IconButton>
          <IconButton>
            <BorderColorOutlined sx={{ color: "#635BFF" }} />
          </IconButton>
          <IconButton>
            <DeleteOutline color="error" />
          </IconButton>
        </TableCell>
      </TableRow>
      <TableRow sx={{ "& > *": { borderBottom: "unset" }, borderBottom: 0 }}>
        <TableCell style={{ padding: 0 }} colSpan={12}>
          <Collapse in={open} timeout="auto" unmountOnExit>
            <Box>
              <Table size="small" aria-label="purchases">
                {/* <TableHead>
                  <TableRow>
                    <TableCell />
                    <TableCell>Parameters</TableCell>
                    <TableCell align="right">ID Ref. No.</TableCell>
                    <TableCell align="right">Nabl</TableCell>
                    <TableCell align="right">Responsible Department</TableCell>
                    <TableCell align="right">Base Price</TableCell>
                    <TableCell align="right">Action</TableCell>
                  </TableRow>
                </TableHead> */}
                <TableBody>
                  {parameterData.map((item) => (
                    <TableRow key={item._id}>
                      <TableCell width={'6%'} />
                      <TableCell width={'39%'} align="left" component="th" scope="row">
                        {item.name}
                      </TableCell>
                      <TableCell width={'8%'} align="left">{item.uid}</TableCell>
                      <TableCell width={'8%'} align="center">
                        {item.isNabl ? (
                          <CheckCircleOutline color="success" />
                        ) : (
                          <CancelOutlined color="error" />
                        )}
                      </TableCell>
                      <TableCell align="left" width={'20%'}>
                        {item?.department?.name}
                      </TableCell>
                      <TableCell width={'8%'} align="right">{item.price}</TableCell>
                      <TableCell width={'11%'} align="right">
                        <IconButton>
                          <BorderColorOutlined sx={{ color: "#635BFF" }} />
                        </IconButton>
                        <IconButton>
                          <DeleteOutline color="error" />
                        </IconButton>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </Box>
          </Collapse>
        </TableCell>
      </TableRow>
    </React.Fragment>
  );
}

export default function CollapsibleTable({
  data,
  setAlertData,
}: {
  data: StandardType[];
  setAlertData: ({ severity, message }: CustomAlertType) => void;
}) {
  const [departmentData, setDepartmentData] = React.useState<DepartmentType[]>(
    []
  );

  React.useEffect(() => {
    (async () => {
      const response = await ApiManager.fetchDepartments();
      console.log(response);
      if (Array.isArray(response.data)) {
        setDepartmentData(response.data);
      }
    })();
  }, []);

  return (
    <TableContainer sx={{height:426}} component={Paper}>
      <Table stickyHeader size="small" aria-label="collapsible table">
        <TableHead>
          <TableRow>
            <TableCell width={'5%'} />
            <TableCell width={'40%'} align="left">Parameters</TableCell>
            <TableCell width={'8%'} align="left">ID Ref. No.</TableCell>
            <TableCell width={'8%'} align="center">Nabl</TableCell>
            <TableCell width={'20%'} align="left">Responsible Department</TableCell>
            <TableCell width={'8%'} align="right">Base Price</TableCell>
            <TableCell width={'11%'} align="right">Action</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {data.map((row) => (
            <Row
              departmentData={departmentData}
              setAlertData={setAlertData}
              key={row.name}
              row={row}
            />
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
}
