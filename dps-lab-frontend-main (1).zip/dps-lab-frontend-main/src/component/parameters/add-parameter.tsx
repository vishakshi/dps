import {
  Button,
  Dialog,
  DialogContent,
  Box,
  DialogTitle,
  TextField,
  Grid2 as Grid,
  Typography,
  FormControlLabel,
  Chip,
  Autocomplete,
} from "@mui/material";
import { useForm } from "react-hook-form";
import { ApiManager } from "../../api-manager/api-manager";
import { CustomAlertType, DepartmentType, StandardType } from "../../static-data/type";
import Android12Switch from "../android-switch";
type DialogProps = {
  onOpen: boolean;
  onClose: VoidFunction;
  setAlertData: ({ severity, message }: CustomAlertType) => void;
  departmentData:DepartmentType[];
  standard:StandardType;
};

type FormData = {
  name: string;
  isNabl: Boolean;
  department: string;
  price: string;
  standard:string;
  currency:string;
};

const AddParameter = ({ onOpen, onClose, setAlertData,departmentData,standard }: DialogProps) => {
  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
  } = useForm<FormData>({
    defaultValues: {
      name: "",
      isNabl: false,
      department: "",
      price: "",
      standard:standard?._id,
      currency:"INR"
    },
  });

  const handleSubmitValues = async (data: FormData) => {
    console.log(data);
    const response = await ApiManager.createParameter(data);
    console.log(response);
    if (response?.status >= 200 && response?.status <= 250) {
      console.log(response);
      onClose();
      setAlertData({ severity: "success", message: "Data added successfully" });
    } else {
      const errorArr = response?.data?.message;
      if (Array.isArray(errorArr)) {
        errorArr.map((data) => {
          setAlertData({ severity: "error", message: data });
        });
      }
    }
  };

  return (
    <Dialog fullWidth maxWidth="md" open={onOpen} onClose={onClose}>
      <DialogTitle>Add Parameter For ({standard?.name})</DialogTitle>
      <DialogContent>
        <Box
          component="form"
          autoComplete="off"
          onSubmit={handleSubmit(handleSubmitValues)}
          pt={1}
        >
          <Grid container spacing={2}>
            <Grid size={{ xs: 12, md: 6 }}>
              <TextField
                {...register("name", { required: "Name is required" })}
                label="Parameter Name"
                fullWidth
                variant="outlined"
                error={!!errors.name}
                helperText={errors.name ? errors.name.message : ""}
              />
            </Grid>
            <Grid size={{ xs: 12, md: 6 }}>
              <Autocomplete
                // disablePortal
                options={departmentData}
                fullWidth
                getOptionLabel={(option)=>option.name}
                renderInput={(params) => (
                  <TextField {...params} label="Department" />
                )}
                onChange={(_event:any,newValue:DepartmentType|null)=> setValue('department',newValue?._id ? newValue?._id : '')}
              />
            </Grid>
            <Grid size={{ xs: 12, md: 6 }}>
              <TextField
                {...register("price", { required: "Price is required" })}
                label="Price"
                fullWidth
                variant="outlined"
              />
            </Grid>
            <Grid
              sx={{ display: "flex", alignItems: "center" }}
              size={{ xs: 6, md: 3 }}
            >
              <FormControlLabel
                {...register('isNabl')}
                control={<Android12Switch color="success" sx={{ m: 1 }} />}
                label="Is Nabl?"
              />
            </Grid>
            <Grid
              sx={{ display: "flex", alignItems: "center", gap: 1 }}
              size={{ xs: 6, md: 3 }}
            >
              <Typography variant="body1">Currency</Typography>
              <Chip color="primary" label="INR" />
            </Grid>
          </Grid>
          <Box
            sx={{ display: "flex", justifyContent: "flex-end", gap: 1, mt: 2 }}
          >
            <Button variant="contained" onClick={onClose}>
              Close
            </Button>
            <Button variant="contained" type="submit">
              Add
            </Button>
          </Box>
        </Box>
      </DialogContent>
    </Dialog>
  );
};

export default AddParameter;
