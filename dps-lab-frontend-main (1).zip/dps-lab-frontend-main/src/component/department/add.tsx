import { Button, Dialog,  DialogContent, Box, DialogTitle, TextField } from "@mui/material";
import { useForm } from "react-hook-form";
import { ApiManager } from "../../api-manager/api-manager";
import { CustomAlertType } from "../../static-data/type";
import { departmentSchema } from "../../static-data/validation-schema";
import { zodResolver } from "@hookform/resolvers/zod";

type DialogProps = {
	onOpen:boolean;
	onClose:VoidFunction;
	recall:VoidFunction;
	setAlertData:({severity,message}:CustomAlertType)=>void
}

type FormData = {
	name:string;
}


const AddDepartment = ({onOpen,onClose,recall,setAlertData}:DialogProps) => {
	const {register,handleSubmit} = useForm<FormData>({
		defaultValues:{
			name:''
		},
		resolver:zodResolver(departmentSchema)
	});

	const handleSubmitValues = async (data:FormData) => {
		const response = await ApiManager.createDepartment(data);
		console.log(response)
		if(response?.status >= 200 && response?.status <= 250){
			console.log(response)
			onClose();
			recall();
			setAlertData({severity:'success',message:'Data added successfully'})
		}else{
			const errorArr = response?.data?.message;
			if(Array.isArray(errorArr)){
				errorArr.map((data)=>{
					setAlertData({severity:'error',message:data});
				})
			}
		}
	}

  return (
	<Dialog
	    fullWidth
        maxWidth='md'
        open={onOpen}
        onClose={onClose}
      >
        <DialogTitle>Add Department</DialogTitle>
        <DialogContent>
         <Box component='form' onSubmit={handleSubmit(data=>handleSubmitValues(data))} pt={1}>
		 <TextField {...register('name')} label="Department Name"  fullWidth variant="outlined" />
        <Box sx={{display:'flex',justifyContent:'flex-end',gap:1,mt:2}}>
          <Button variant="contained" onClick={onClose}>Close</Button>
		  <Button variant="contained" type="submit">Add</Button>
        </Box>
		 </Box>
        </DialogContent>
      </Dialog>
  )
}

export default AddDepartment