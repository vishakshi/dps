import { Box,Typography } from '@mui/material'
import React from 'react'
import { useNavigate } from 'react-router-dom'

interface MainCardProps {
  heading:string;
  description:string;
  icon:React.ReactNode;
  path:string;
}
const MainCard:React.FC<MainCardProps> = ({heading,description,icon,path}) => {
  const navigate = useNavigate();
  return (
	<Box onClick={()=>navigate(path)} sx={{border:'2px solid aqua',borderRadius:5,py:2,px:1,minHeight:110,backgroundColor:'#fff',cursor:'pointer'}}>
    <Box sx={{display:'flex',justifyContent:'space-between',alignItems:'center',pb:1}}>
      <Typography variant='h3'>{heading}</Typography>
      {icon}
    </Box>
    <Typography variant='subtitle1' color='secondary'>
    {description}
    </Typography>
  </Box>
  )
}

export default MainCard