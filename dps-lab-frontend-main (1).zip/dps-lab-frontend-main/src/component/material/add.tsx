import { Button, Dialog,  DialogContent, Box, DialogTitle, TextField } from "@mui/material";
import { useForm } from "react-hook-form";
import { ApiManager } from "../../api-manager/api-manager";
import { CustomAlertType } from "../../static-data/type";
import { useState } from "react";
import SubmitButton from "../submit-btn";
import { materialSchema } from "../../static-data/validation-schema";
import { zodResolver } from "@hookform/resolvers/zod";
type DialogProps = {
	onOpen:boolean;
	onClose:VoidFunction;
	recall:VoidFunction;
	setAlertData:({}:CustomAlertType) => void;
}

type FormData = {
	name:string;
}

const AddMaterial = ({onOpen,onClose,recall,setAlertData}:DialogProps) => {
	const [isSubmitting,setIsSubmitting] = useState(false);
	const {register,handleSubmit} = useForm<FormData>({
		defaultValues:{
			name:''
		},
		resolver:zodResolver(materialSchema)
	});

	const handleSubmitValues = async (data:FormData) => {
		setIsSubmitting(true);
		const response = await ApiManager.createMaterial(data);
		console.log(response)
		if(response?.status >= 200 && response?.status <= 250){
			console.log(response)
			onClose();
			recall();
			setAlertData({severity:'success',message:'Data added successfully'})
		}else{
			const errorArr = response?.data?.message;
			if(Array.isArray(errorArr)){
				errorArr.map((data)=>{
					setAlertData({severity:'error',message:data});
				})
			}
		}
		setIsSubmitting(false);
	}

  return (
	<Dialog
	    fullWidth
        maxWidth='md'
        open={onOpen}
        onClose={onClose}
      >
        <DialogTitle>Add Material</DialogTitle>
        <DialogContent>
         <Box component='form' onSubmit={handleSubmit(data=>handleSubmitValues(data))} pt={1}>
		 <TextField {...register('name')} label="Material Name"  fullWidth variant="outlined" />
        <Box sx={{display:'flex',justifyContent:'flex-end',gap:1,mt:2}}>
          <Button variant="contained" onClick={onClose}>Close</Button>
		  {/* <Button variant="contained" type="submit">Add</Button> */}
		  <SubmitButton isLoading={isSubmitting} text="Add"/>
        </Box>
		 </Box>
        </DialogContent>
      </Dialog>
  )
}

export default AddMaterial