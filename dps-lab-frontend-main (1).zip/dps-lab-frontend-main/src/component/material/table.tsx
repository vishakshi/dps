import Box from '@mui/material/Box';
import { DataGrid, GridColDef } from '@mui/x-data-grid';
import { DepartmentType } from '../../static-data/type';

const columns: GridColDef[] = [
  { field: 'uid', headerName: 'Material Code',width:180},
  {
    field: 'name',
    headerName: 'Material Name',
    flex:7,
	  
  },
  {
    field: 'createdAt',
    headerName: 'Created At',
    width:150,
    type:'date',
    valueGetter:(value)=> value && new Date(value)
  },
  {
    field: 'action',
    headerName: 'Action',
    width:150,
  },
];

export default function MaterialTable({data}:{data:DepartmentType[]}) {
  return (
    <Box sx={{ height: 400, width: '100%' }}>
      <DataGrid
        rows={data}
        getRowId={(row)=>row._id}
        columns={columns}
        initialState={{
          pagination: {
            paginationModel: {
              pageSize: 5,
            },
          },
        }}
        pageSizeOptions={[5,10,15]}
        // checkboxSelection
        disableRowSelectionOnClick
      />
    </Box>
  );
}