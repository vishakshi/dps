import { Box, Button, CircularProgress } from "@mui/material";

const SubmitButton = ({
  text,
  isLoading,
}: {
  text: string;
  isLoading: boolean;
}) => {
  return (
    <Box sx={{position:'relative'}}>
      <Button disabled={isLoading} variant="contained" type="submit">{text} {isLoading && <CircularProgress size={20} sx={{position:'absolute'}} />}</Button>
    </Box>
  );
};

export default SubmitButton;
