import React, { useState } from 'react';
import {
  Button,
  Dialog,
  DialogContent,
  Box,
  DialogTitle,
  TextField,
  Grid2 as Grid,
  Typography,
  MenuItem,
  Select,
  InputLabel,
  FormControl
} from "@mui/material";
import { useForm } from "react-hook-form";
import { ApiManager } from "../../api-manager/api-manager";
import { CustomAlertType } from "../../static-data/type";
import { zodResolver } from "@hookform/resolvers/zod";
import { sampleSchema } from '../../static-data/validation-schema';

type DialogProps = {
  onOpen: boolean;
  onClose: VoidFunction;
  recall: VoidFunction;
  setAlertData: ({ severity, message }: CustomAlertType) => void;
};

type FormData = {
  sampleType: string;
  description: string;
  condition: string;
  packing: string;
  size: string;
  projectName: string;
  collectedBy: string;
  receivedBy: string;
  receivedOn: string;
  testStartedOn: string;
  testEndOn: string;
  image: FileList; // Field for image upload
};

interface FormValues {
  [key: string]: any; 
}

const SampleForm = ({ onOpen, onClose, recall, setAlertData }: DialogProps) => {
  const [selectedImageName, setSelectedImageName] = useState<string | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null); // State for image preview
  const { register, handleSubmit, formState: { errors } } = useForm<FormData>({
    defaultValues: {
      sampleType: '',
      description: '',
      condition: '',
      packing: '',
      size: '',
      projectName: '',
      collectedBy: '',
      receivedBy: '',
      receivedOn: '',
      testStartedOn: '',
      testEndOn: '',
      image: undefined // Default value for image
    },
    resolver: zodResolver(sampleSchema) // Adjust this schema
  });

  const handleImageChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (files && files.length > 0) {
      setSelectedImageName(files[0].name);
      const file = files[0];
      const previewUrl = URL.createObjectURL(file);
      setImagePreview(previewUrl); // Set the preview URL
    } else {
      setSelectedImageName(null);
      setImagePreview(null); // Reset the preview if no file is selected
    }
  };

  const handleSubmitValues = async (data: FormValues) => {
    console.log(data)
    const formData = new FormData();
    for (const key in data) {
      if (key === 'image' && data.image.length > 0) {
        formData.append(key, data.image[0]); // Append the image file
      } else {
        formData.append(key, data[key]);
      }
    }

    const response = await ApiManager.createSamples(formData); // Adjust to your API method for creating a sample
    console.log(response);
  
    if (response?.status >= 200 && response?.status <= 250) {
      console.log(response);
      onClose();
      recall();
      setAlertData({ severity: 'success', message: 'Data added successfully' });
    } else {
      const errorArr = response?.data?.message;
      if (Array.isArray(errorArr)) {
        errorArr.forEach((errorMessage) => {
          setAlertData({ severity: 'error', message: errorMessage });
        });
      } else {
        setAlertData({ severity: 'error', message: 'An unexpected error occurred' });
      }
    }
  };

  return (
    <Dialog fullWidth maxWidth="md" open={onOpen} onClose={onClose}>
      <DialogTitle>Add Sample</DialogTitle>
      <DialogContent>
        <Box component="form" onSubmit={handleSubmit(handleSubmitValues)} pt={1}>
          <Grid container spacing={1}>
            {/* Sample Details Section */}
            <Grid size={{xs:12}}>
              <Typography variant="h6" fontWeight={700}>Sample Details :</Typography>
            </Grid>
            <Grid size={{xs:12,md:6}}>
              <FormControl fullWidth variant="outlined" margin="normal">
                <InputLabel>Sample Type</InputLabel>
                <Select
                  {...register("sampleType", { required: 'Sample Type is required' })}
                  error={!!errors.sampleType}
                >
                  <MenuItem value="Bricks">Bricks</MenuItem>
                  <MenuItem value="Concrete">Concrete</MenuItem>
                  <MenuItem value="Aggregate">Aggregate</MenuItem>
                  <MenuItem value="Wood">Wood</MenuItem>
                </Select>
                {errors.sampleType && <Typography color="error">{errors.sampleType.message}</Typography>}
              </FormControl>
            </Grid>
            <Grid size={{xs:12,md:6}}>
              <TextField
                {...register('description', { required: 'Description is required' })}
                label="Description"
                fullWidth
                variant="outlined"
                error={!!errors.description}
                helperText={errors.description ? errors.description.message : ''}
                margin="normal"
              />
            </Grid>

            {/* Additional Details Section */}
            <Grid size={{xs:12}}>
              <Typography variant="h6" fontWeight={700}>Additional Details:</Typography>
            </Grid>
            <Grid size={{xs:12,md:6}}>
              <FormControl fullWidth variant="outlined" margin="normal">
                <InputLabel>Condition</InputLabel>
                <Select
                  {...register("condition", { required: 'Condition is required' })}
                  error={!!errors.condition}
                >
                  <MenuItem value="Acceptable">Acceptable</MenuItem>
                  <MenuItem value="Damaged">Damaged</MenuItem>
                </Select>
                {errors.condition && <Typography color="error">{errors.condition.message}</Typography>}
              </FormControl>
            </Grid>
            <Grid size={{xs:12,md:6}}>
              <FormControl fullWidth variant="outlined" margin="normal">
                <InputLabel>Packing</InputLabel>
                <Select
                  {...register("packing", { required: 'Packing is required' })}
                  error={!!errors.packing}
                >
                  <MenuItem value="Sealed">Sealed</MenuItem>
                  <MenuItem value="Unsealed">Unsealed</MenuItem>
                </Select>
                {errors.packing && <Typography color="error">{errors.packing.message}</Typography>}
              </FormControl>
            </Grid>
            <Grid size={{xs:12,md:6}}>
              <TextField
                {...register('size', { required: 'Size/Quantity is required' })}
                label="Size / Quantity"
                fullWidth
                variant="outlined"
                error={!!errors.size}
                helperText={errors.size ? errors.size.message : ''}
                margin="normal"
              />
            </Grid>

            {/* Project Details Section */}
            <Grid size={{xs:12}}>
              <Typography variant="h6" fontWeight={700}>Project Details:</Typography>
            </Grid>
            <Grid size={{xs:12,md:6}}>
              <TextField
                {...register('projectName', { required: 'Project Name is required' })}
                label="Project Name"
                fullWidth
                variant="outlined"
                error={!!errors.projectName}
                helperText={errors.projectName ? errors.projectName.message : ''}
                margin="normal"
              />
            </Grid>
            <Grid size={{xs:12,md:6}}>
              <TextField
                {...register('collectedBy', { required: 'Collected By is required' })}
                label="Collected By"
                fullWidth
                variant="outlined"
                error={!!errors.collectedBy}
                helperText={errors.collectedBy ? errors.collectedBy.message : ''}
                margin="normal"
              />
            </Grid>
            <Grid size={{xs:12,md:6}}>
              <TextField
                {...register('receivedBy', { required: 'Received By is required' })}
                label="Received By"
                fullWidth
                variant="outlined"
                error={!!errors.receivedBy}
                helperText={errors.receivedBy ? errors.receivedBy.message : ''}
                margin="normal"
              />
            </Grid>
            <Grid size={{xs:12,md:6}}>
              <TextField
                {...register('receivedOn', { required: 'Received On is required' })}
                label="Received On"
                fullWidth
                type="date"
                InputLabelProps={{ shrink: true }}
                variant="outlined"
                error={!!errors.receivedOn}
                helperText={errors.receivedOn ? errors.receivedOn.message : ''}
                margin="normal"
              />
            </Grid>
            <Grid size={{xs:12,md:6}}>
              <TextField
                {...register('testStartedOn', { required: 'Test Started On is required' })}
                label="Test Started On"
                fullWidth
                type="date"
                InputLabelProps={{ shrink: true }}
                variant="outlined"
                error={!!errors.testStartedOn}
                helperText={errors.testStartedOn ? errors.testStartedOn.message : ''}
                margin="normal"
              />
            </Grid>
            <Grid size={{xs:12,md:6}}>
              <TextField
                {...register('testEndOn', { required: 'Test End On is required' })}
                label="Test End On"
                fullWidth
                type="date"
                InputLabelProps={{ shrink: true }}
                variant="outlined"
                error={!!errors.testEndOn}
                helperText={errors.testEndOn ? errors.testEndOn.message : ''}
                margin="normal"
              />
            </Grid>
            <Grid size={{xs:12,md:6}}>
              <input
                type="file"
                accept="image/*"
                {...register("image")}
                onChange={handleImageChange}
                style={{ marginTop: 16 }}
              />
              {selectedImageName && (
                <Typography variant="body1" marginTop={1}>
                  Selected Image: {selectedImageName}
                </Typography>
              )}
              {imagePreview && (
                <img
                  src={imagePreview}
                  alt="Image Preview"
                  style={{ marginTop: 16, maxWidth: '100%', maxHeight: '300px', objectFit: 'cover' }}
                />
              )}
            </Grid>
            <Grid size={{xs:12}}>
              <Button type="submit" variant="contained" color="primary" style={{ marginTop: 16 }}>
                Submit
              </Button>
            </Grid>
          </Grid>
        </Box>
      </DialogContent>
    </Dialog>
  );
};

export default SampleForm;
