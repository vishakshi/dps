
import Box from '@mui/material/Box';
import { DataGrid, GridColDef, GridActionsCellItem } from '@mui/x-data-grid';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/DeleteOutlined';
import ScienceIcon from '@mui/icons-material/Science'; // Use the Science icon
import { SampleType } from '../../static-data/type';

const SampleTable = ({ data }: { data: SampleType[] }) => {
  const columns: GridColDef[] = [
    {
      field: 'id',
      headerName: 'Sample ID',
      width: 150,
      renderCell: (params) => (
        <span style={{ color: 'blue', textDecoration: 'underline', cursor: 'pointer' }}>
          {params.value}
        </span>
      ),
    },
    {
      field: 'type',
      headerName: 'Sample Type',
      width: 150,
    },
    {
      field: 'description',
      headerName: 'Sample Description',
      width: 250,
    },
    {
      field: 'receivedOn',
      headerName: 'Received On',
      width: 150,
    },
    {
      field: 'condition',
      headerName: 'Condition',
      width: 150,
    },
    {
      field: 'packing',
      headerName: 'Packing',
      width: 150,
    },
    {
      field: 'status',
      headerName: 'Status',
      width: 150,
      renderCell: (params) => (
        <span style={{ color: params.value === 'In Progress' ? 'orange' : 'green' }}>
          {params.value}
        </span>
      ),
    },
    {
      field: 'actions',
      headerName: 'Action',
      width: 150,
      type: 'actions',
      getActions: () => [
        <GridActionsCellItem
          icon={<ScienceIcon />}
          label="View"
          color="inherit"
        />,
        <GridActionsCellItem
          icon={<EditIcon />}
          label="Edit"
          color="inherit"
        />,
        <GridActionsCellItem
          icon={<DeleteIcon />}
          label="Delete"
          color="inherit"
        />,
      ],
    },
  ];

  return (
    <Box sx={{ height: 400, width: '100%' }}>
      <DataGrid
        getRowId={(row) => row.id} // Adjust according to your data structure
        rows={data}
        columns={columns}
        initialState={{
          pagination: {
            paginationModel: {
              pageSize: 5,
            },
          },
        }}
        pageSizeOptions={[5, 10, 15]}
        disableRowSelectionOnClick
      />
    </Box>
  );
};

export default SampleTable;
