import Box from '@mui/material/Box';
import { DataGrid, GridColDef } from '@mui/x-data-grid';
import { DepartmentType } from '../../static-data/type';

const columns: GridColDef[] = [
  { field: 'id',
     headerName: 'Department Code',
     width:150
    },
  {
    field: 'testDescription',
    headerName: 'Test Description',
	  minWidth:450,
  },
  {
    field: 'testParameter',
    headerName: 'Test Parameter',
	  minWidth:200,
  },
  {
    field: 'testMethod',
    headerName: 'Test Method/Standard',
	  minWidth:200,
  },
  {
    field: 'department',
    headerName: 'Department',
	  minWidth:150,
  },
  {
    field: 'assignTo',
    headerName: 'Assigned To',
	  minWidth:150,
  },
  {
    field: 'status',
    headerName: 'Status',
	  minWidth:150,
  },
  {
    field: 'action',
    headerName: 'Action',
    width:100,
  },
];

export default function TestsTable({data}:{data:DepartmentType[]}) {
  return (
    <Box sx={{ height: 400, width: '100%' }}>
      <DataGrid
        rows={data}
        getRowId={(row)=>row._id}
        columns={columns}
        initialState={{
          pagination: {
            paginationModel: {
              pageSize: 5,
            },
          },
        }}
        pageSizeOptions={[5,10,15]}
        // checkboxSelection
        disableRowSelectionOnClick
      />
    </Box>
  );
}