import Box from '@mui/material/Box';
import { DataGrid, GridColDef, GridActionsCellItem } from '@mui/x-data-grid';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/DeleteOutlined';
import { BookingType } from '../../static-data/type'; // Adjust the path as necessary

interface BookingTableProps {
    data: BookingType[];
}

const BookingTable: React.FC<BookingTableProps> = ({ data }) => {
    const columns: GridColDef[] = [
        {
            field: 'bookingId',
            headerName: 'Booking ID', 
            width: 150,
        },
        {
            field: 'customerName',
            headerName: 'Customer Name', 
            width: 200,
        },
        {
            field: 'bookingDate',
            headerName: 'Booking Date',
            width: 150,
        },
        {
            field: 'dueDate',
            headerName: 'Due Date',
            width: 150,
        },
        {
            field: 'status',
            headerName: 'Status', // Status of the booking
            width: 150,
        },
        {
            field: 'comments',
            headerName: 'Comments', // Additional comments
            width: 250,
        },
        {
            field: 'actions',
            headerName: 'Actions',
            width: 150,
            type: 'actions',
            getActions: (params) => [
                <GridActionsCellItem
                    icon={<EditIcon />}
                    label="Edit"
                    onClick={() => console.log(`Edit Booking ID: ${params.id}`)}
                    color="inherit"
                />,
                <GridActionsCellItem
                    icon={<DeleteIcon />}
                    label="Delete"
                    color="inherit"
                    onClick={() => console.log(`Delete Booking ID: ${params.id}`)}
                />,
            ],
        },
    ];

    return (
        <Box sx={{ height: 400, width: '100%' }}>
            <DataGrid
                rows={data}
                getRowId={(row) => row.bookingId} // Unique identifier for each booking
                columns={columns}
                initialState={{
                    pagination: {
                        paginationModel: {
                            pageSize: 5,
                        },
                    },
                }}
                pageSizeOptions={[5, 10, 15]}
                disableRowSelectionOnClick
            />
        </Box>
    );
};

export default BookingTable;
