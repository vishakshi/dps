import { Button, Dialog, DialogContent,DialogTitle, TextField, Grid } from '@mui/material';
import { useForm } from 'react-hook-form';
import { ApiManager } from '../../api-manager/api-manager';
import { CustomAlertType } from '../../static-data/type';
import { bookingSchema } from "../../static-data/validation-schema";
import { zodResolver } from "@hookform/resolvers/zod";

type DialogProps = {
  onOpen: boolean;
  onClose: VoidFunction;
  recall: VoidFunction;
  setAlertData: ({ severity, message }: CustomAlertType) => void;
};

type FormData = {
  customerName: string;
  billTo: string;
  shipTo: string;
  reqDate: string;
  reqRefNo: string;
  bookingDate: string;
  dueDate: string;
  comments: string;
  payMode: string;
  reportMode: string;
  attachment: null;
};

const AddBooking = ({ onOpen, onClose, recall, setAlertData }: DialogProps) => {
  const { register, handleSubmit, formState: { errors } } = useForm<FormData>({
    defaultValues: {
      customerName: '',
      billTo: '',
      shipTo: '',
      reqDate: '',
      reqRefNo: '',
      bookingDate: '',
      dueDate: '',
      comments: '',
      payMode: '',
      reportMode: '',
      attachment: null,
    },
    resolver:zodResolver(bookingSchema)

  });

  const handleSubmitValues = async (data: FormData) => {
    const response = await ApiManager.createBookings(data);
    if (response?.status >= 200 && response?.status <= 250) {
      onClose();
      recall();
      setAlertData({ severity: 'success', message: 'Data added successfully' });
    } else {
      const errorArr = response?.data?.message;
      if (Array.isArray(errorArr)) {
        errorArr.forEach((error) => {
          setAlertData({ severity: 'error', message: error });
        });
      }
    }
  };

  return (
    <Dialog open={onOpen} onClose={onClose}>
      <DialogTitle>Add Booking</DialogTitle>
      <DialogContent>
        <form onSubmit={handleSubmit(handleSubmitValues)}>
          <Grid container spacing={2}>
            <Grid item xs={12}>
              <TextField
                label="Customer Name"
                fullWidth
                {...register('customerName', { required: 'Customer name is required' })}
                error={!!errors.customerName}
                helperText={errors.customerName?.message}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                label="Bill To"
                fullWidth
                {...register('billTo', { required: 'Bill to is required' })}
                error={!!errors.billTo}
                helperText={errors.billTo?.message}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                label="Ship To"
                fullWidth
                {...register('shipTo', { required: 'Ship to is required' })}
                error={!!errors.shipTo}
                helperText={errors.shipTo?.message}
              />
            </Grid>
            <Grid item xs={6}>
              <TextField
                label="Request Date"
                type="date"
                fullWidth
                {...register('reqDate', { required: 'Request date is required' })}
                error={!!errors.reqDate}
                helperText={errors.reqDate?.message}
                InputLabelProps={{
                  shrink: true,
                }}
              />
            </Grid>
            <Grid item xs={6}>
              <TextField
                label="Request Ref No"
                fullWidth
                {...register('reqRefNo', { required: 'Request ref no is required' })}
                error={!!errors.reqRefNo}
                helperText={errors.reqRefNo?.message}
              />
            </Grid>
            <Grid item xs={6}>
              <TextField
                label="Booking Date"
                type="date"
                fullWidth
                {...register('bookingDate', { required: 'Booking date is required' })}
                error={!!errors.bookingDate}
                helperText={errors.bookingDate?.message}
                InputLabelProps={{
                  shrink: true,
                }}
              />
            </Grid>
            <Grid item xs={6}>
              <TextField
                label="Due Date"
                type="date"
                fullWidth
                {...register('dueDate', { required: 'Due date is required' })}
                error={!!errors.dueDate}
                helperText={errors.dueDate?.message}
                InputLabelProps={{
                  shrink: true,
                }}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                label="Comments"
                fullWidth
                multiline
                rows={4}
                {...register('comments')}
              />
            </Grid>
            <Grid item xs={6}>
              <TextField
                label="Payment Mode"
                fullWidth
                {...register('payMode')}
              />
            </Grid>
            <Grid item xs={6}>
              <TextField
                label="Report Mode"
                fullWidth
                {...register('reportMode')}
              />
            </Grid>
            <Grid item xs={12}>
              <Button variant="contained" color="primary" type="submit">
                Submit
              </Button>
              <Button variant="outlined" onClick={onClose} style={{ marginLeft: 8 }}>
                Cancel
              </Button>
            </Grid>
          </Grid>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default AddBooking;

// import { Button, Dialog, DialogContent, Box, DialogTitle, TextField, Grid2 as Grid, Typography} from "@mui/material";
// import { useForm } from "react-hook-form";
// import { ApiManager } from "../../api-manager/api-manager";
// import { CustomAlertType } from "../../static-data/type";
// type DialogProps = {
//   onOpen: boolean;
//   onClose: VoidFunction;
//   recall:VoidFunction;
// 	setAlertData:({severity,message}:CustomAlertType)=>void
// };

// type FormData = {
//   customerName: string,
//   billTo: string,
//   shipTo: string,
//   reqDate: string,
//   reqRefNo: string,
//   bookingDate: string,
//   dueDate: string,
//   comments: string,
//   payMode: string,
//   reportMode: string,
//   attachment: null,
// };

// const AddBooking = ({ onOpen, onClose, recall, setAlertData }: DialogProps) => {
//   const { register, handleSubmit, formState: { errors } } = useForm<FormData>({
//     defaultValues: {
//     customerName: '',
//     billTo: '',
//     shipTo: '',
//     reqDate: '',
//     reqRefNo: '',
//     bookingDate: '',
//     dueDate: '',
//     comments: '',
//     payMode: '',
//     reportMode: '',
//     attachment: null,
//     },
//   });

//   const handleSubmitValues = async (data: FormData) => {
//     const response = await ApiManager.createEmployee(data);
//     console.log(response)
// 		if(response?.status >= 200 && response?.status <= 250){
// 			console.log(response)
// 			onClose();
// 			recall();
// 			setAlertData({severity:'success',message:'Data added successfully'})
// 		}else{
// 			const errorArr = response?.data?.message;
// 			if(Array.isArray(errorArr)){
// 				errorArr.map((data)=>{
// 					setAlertData({severity:'error',message:data});
// 				})
// 			}
// 		}
//   };

//     return (
//     <Box sx={{ height: 400, width: '100%' }}>
//       <Grid container spacing={2}>
//         <Grid item xs={12}>
//         <Typography variant="h6" fontWeight={700}>Client:</Typography>
//         </Grid>
//         <Grid item xs={6}>
//           <TextField
//             label="Customer"
//             name="customerName"
//             fullWidth
//             value={formData.customerName}
//             onChange={handleInputChange}
//           />
//         </Grid>
//         <Grid item xs={6}>
//           <TextField
//             label="Bill To"
//             name="billTo"
//             fullWidth
//             value={formData.billTo}
//             onChange={handleInputChange}
//           />
//         </Grid>
//         <Grid item xs={6}>
//           <TextField
//             label="Ship To"
//             name="shipTo"
//             fullWidth
//             value={formData.shipTo}
//             onChange={handleInputChange}
//           />
//         </Grid>

//         {/* Contact Section */}
//         <Grid item xs={12}>
//         <Typography variant="h6" fontWeight={700}>Contact:</Typography>
//         </Grid>
//         <Grid item xs={6}>
//           <TextField
//             label="Name"
//             name="contactName"
//             fullWidth
//             value="Mohd. Hamid Shaikh"
//             disabled
//           />
//         </Grid>
//         <Grid item xs={6}>
//           <TextField
//             label="Phone"
//             name="contactPhone"
//             fullWidth
//             value="+91 79911 67640"
//             disabled
//           />
//         </Grid>
//         <Grid item xs={6}>
//           <TextField
//             label="Email"
//             name="contactEmail"
//             fullWidth
//             value="saqreen@gmail.com"
//             disabled
//           />
//         </Grid>

//         {/* Booking Details Section */}
//         <Grid item xs={12}>
//         <Typography variant="h6" fontWeight={700}>Booking Details:</Typography>
//         </Grid>
//         <Grid item xs={6}>
//           <TextField
//             label="Req. Date"
//             name="reqDate"
//             type="date"
//             fullWidth
//             value={formData.reqDate}
//             onChange={handleInputChange}
//             InputLabelProps={{ shrink: true }}
//           />
//         </Grid>
//         <Grid item xs={6}>
//           <TextField
//             label="Req. Ref No"
//             name="reqRefNo"
//             fullWidth
//             value={formData.reqRefNo}
//             onChange={handleInputChange}
//           />
//         </Grid>
//         <Grid item xs={6}>
//           <TextField
//             label="Booking Date"
//             name="bookingDate"
//             type="date"
//             fullWidth
//             value={formData.bookingDate}
//             onChange={handleInputChange}
//             InputLabelProps={{ shrink: true }}
//           />
//         </Grid>
//         <Grid item xs={6}>
//           <TextField
//             label="Due Date"
//             name="dueDate"
//             type="date"
//             fullWidth
//             value={formData.dueDate}
//             onChange={handleInputChange}
//             InputLabelProps={{ shrink: true }}
//           />
//         </Grid>
//         <Grid item xs={12}>
//           <TextField
//             label="Comments"
//             name="comments"
//             fullWidth
//             multiline
//             value={formData.comments}
//             onChange={handleInputChange}
//           />
//         </Grid>

//         {/* Payment Mode Section */}
//         <Grid item xs={6}>
//           <Select
//             name="payMode"
//             fullWidth
//             value={formData.payMode}
//             onChange={handleInputChange}
//           >
//             <MenuItem value="cash">Cash</MenuItem>
//             <MenuItem value="credit">Credit</MenuItem>
//           </Select>
//         </Grid>
//         <Grid item xs={6}>
//           <Select
//             name="reportMode"
//             fullWidth
//             value={formData.reportMode}
//             onChange={handleInputChange}
//           >
//             <MenuItem value="byHand">By Hand</MenuItem>
//             <MenuItem value="byMail">By Mail</MenuItem>
//           </Select>
//         </Grid>

//         {/* Attachment Section */}
//         <Grid item xs={12}>
//         <Typography variant="h6" fontWeight={700}>Attachment:</Typography>
//           <input
//             type="file"
//             accept="image/*"
//             name="attachment"
//             onChange={handleFileChange}
//           />
//         </Grid>

//         {/* Save and Close Buttons */}
//         <Grid item xs={12} display="flex" justifyContent="flex-end" gap={2}>
//           <Button variant="outlined" onClick={() => console.log('Form Closed')}>
//             Close
//           </Button>
//           <Button variant="contained" color="primary" onClick={handleSubmit}>
//             Save
//           </Button>
//         </Grid>
//       </Grid>
//     </Box>
//   );
// };

// export default AddBooking;