import Box from '@mui/material/Box';
import { DataGrid, GridColDef ,GridActionsCellItem} from '@mui/x-data-grid';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/DeleteOutlined';
import { CustomerType } from '../../static-data/type';


export default function CustomerTable({data}:{data:CustomerType[]}) {
  
    const columns: GridColDef[] = [
        { 
           field: 'uid',
           headerName: 'Client Code',// client code
           width:180
        },
        {
          field: 'name',
          headerName: 'Client Name',//client name
          flex:1,
        },
        {
          field: 'gstIn',
          headerName: 'GST Number',// GST number
          width:150,
        },
        {
          field: 'contactName',
          headerName: 'Client Contact Name',// contact Name
          flex:1,
        },
        {
          field: 'phone',
          headerName: 'Phone Number',//Phone Number
          width:150,
        },
        {
          field: 'email',
          headerName: 'Email',//Email
          width:250,
        },
        {
          field: 'createdAt',
          headerName: 'Created At',
          width:150,
          type:'date',
          valueGetter:(value)=> value && new Date(value)
        },
        {
            field: 'actions',
            headerName: 'Actions',
            width: 150,
            type: 'actions',
            getActions: (params) => [
              <GridActionsCellItem
                icon={<EditIcon />}
                label="Edit"
                onClick={() => console.log(params.id)}
                color="inherit"
              />,
              <GridActionsCellItem
              icon={<DeleteIcon />}
              label="Delete"
              color="inherit"
                onClick={() => console.log(params.id)}
              />,
            ],
          },
        ];
  return (
    <Box sx={{ height: 400, width: '100%' }}>
      <DataGrid
        rows={data} 
        getRowId={(row)=>row._id}
        columns={columns}
        initialState={{
          pagination: {
            paginationModel: {
              pageSize: 5,
            },
          },
        }}
        pageSizeOptions={[5,10,15]}
        // checkboxSelection
        disableRowSelectionOnClick
      />
    </Box>
  );
}