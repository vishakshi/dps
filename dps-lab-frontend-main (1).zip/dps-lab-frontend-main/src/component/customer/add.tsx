import {
  Box,
  Button,
  Dialog,
  DialogContent,
  DialogTitle,
  TextField,
  Grid2 as Grid,
  Typography
} from "@mui/material";
import { useForm } from "react-hook-form";
import { ApiManager } from "../../api-manager/api-manager";
import { CustomAlertType } from "../../static-data/type";
import { customerSchema } from "../../static-data/validation-schema";
import { zodResolver } from "@hookform/resolvers/zod";

interface DialogProps {
  onOpen: boolean;
  onClose: VoidFunction;
  recall:VoidFunction;
	setAlertData:({severity,message}:CustomAlertType)=>void
}

type FormData = {
  name: string;
  address: string;
  gstIn: string;
  contactName: string;
  phone: string;
  email: string;
};
const CustomerAdd = ({ onOpen, onClose,recall,setAlertData }: DialogProps) => {
  const { register, handleSubmit,formState:{errors} } = useForm<FormData>({
    defaultValues: {
      name: "",
      address: "",
      gstIn: "",
      contactName: "",
      phone: "",
      email: "",
    },
    resolver:zodResolver(customerSchema)
  });

  const handleSubmitValues = async (data: FormData) => {
    const response = await ApiManager.createCustomer(data);
    console.log(response)
		if(response?.status >= 200 && response?.status <= 250){
			console.log(response)
			onClose();
			recall();
			setAlertData({severity:'success',message:'Data added successfully'})
		}else{
			const errorArr = response?.data?.message;
			if(Array.isArray(errorArr)){
				errorArr.map((data)=>{
					setAlertData({severity:'error',message:data});
				})
			}
		}
  };

  const getErrorFields = (fieldName:keyof FormData) => {
    return {
      helperText:errors[fieldName]?.message,
      error:Boolean(errors[fieldName]?.message)
    }
  } 
  return (
    <Dialog fullWidth maxWidth="md" open={onOpen} onClose={onClose}>
      <DialogTitle>Add Customer</DialogTitle>
      <DialogContent>
        <Box
          component="form"
          onSubmit={handleSubmit((data) => handleSubmitValues(data))}
          pt={1}
        >
          <Grid container spacing={2}>
			<Grid size={{xs:12}}>
			<Typography variant="h6" fontWeight={700}>Customer Details:</Typography>
			</Grid>
            <Grid size={{ xs: 12, md: 6 }}>
              <TextField
                {...register("name")}
                label="Customer Name"
                fullWidth
                variant="outlined"
                {...getErrorFields('name')}
              />
            </Grid>
			<Grid size={{ xs: 12, md: 6 }}>
              <TextField
                {...register("address")}
                label="Customer address"
                fullWidth
                variant="outlined"
                {...getErrorFields('address')}
              />
            </Grid>
			<Grid size={{ xs: 12, md: 6 }}>
              <TextField
                {...register("gstIn")}
                label="Customer GSTIN"
                fullWidth
                variant="outlined"
                {...getErrorFields('gstIn')}
              />
            </Grid>
			<Grid size={{xs:12}}>
			<Typography variant="h6" fontWeight={700}>Customer Contact:</Typography>
			</Grid>
			<Grid size={{ xs: 12, md: 6 }}>
              <TextField
                {...register("contactName")}
                label="Contact Name"
                fullWidth
                variant="outlined"
                {...getErrorFields('contactName')}
              />
            </Grid>
			<Grid size={{ xs: 12, md: 6 }}>
              <TextField
                {...register("phone")}
                label="Phone No"
                fullWidth
                variant="outlined"
                {...getErrorFields('phone')}
              />
            </Grid>
			<Grid size={{ xs: 12, md: 6 }}>
              <TextField
                {...register("email")}
                label="Email"
                fullWidth
                variant="outlined"
                {...getErrorFields('email')}
              />
            </Grid>
          </Grid>
          <Box
            sx={{ display: "flex", justifyContent: "flex-end", gap: 1, mt: 2 }}
          >
            <Button variant="contained" onClick={onClose}>
              Close
            </Button>
            <Button variant="contained" type="submit">
              Add
            </Button>
          </Box>
        </Box>
      </DialogContent>
    </Dialog>
  );
};

export default CustomerAdd;
